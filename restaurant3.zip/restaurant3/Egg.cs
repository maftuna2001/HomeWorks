﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace restaurant3
{
    sealed class Egg : CookedFood,IDisposable 
    {
     
        public void Crack() { }
        
        public void DiscardShell() { }
         public void GetQuality() { }
        public override void Cook() { Console.WriteLine("Egg is cooked "); }
        public void Dispose() { }
    }
}
