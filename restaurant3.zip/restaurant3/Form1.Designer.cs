﻿
namespace restaurant3
{
    partial class Form1
    {
        /// <summary>
        /// Обязательная переменная конструктора.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Освободить все используемые ресурсы.
        /// </summary>
        /// <param name="disposing">истинно, если управляемый ресурс должен быть удален; иначе ложно.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Код, автоматически созданный конструктором форм Windows

        /// <summary>
        /// Требуемый метод для поддержки конструктора — не изменяйте 
        /// содержимое этого метода с помощью редактора кода.
        /// </summary>
        private void InitializeComponent()
        {
            this.groupBox1Menu = new System.Windows.Forms.GroupBox();
            this.txtEggCount = new System.Windows.Forms.TextBox();
            this.txtChickenCount = new System.Windows.Forms.TextBox();
            this.cmbDrinks = new System.Windows.Forms.ComboBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label1HowManyEgg = new System.Windows.Forms.Label();
            this.label1HowManyChicken = new System.Windows.Forms.Label();
            this.btnRecieveRequest = new System.Windows.Forms.Button();
            this.btnSendAllCustomerRequest = new System.Windows.Forms.Button();
            this.btnServePreparedFood = new System.Windows.Forms.Button();
            this.label1Results = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.txtResult = new System.Windows.Forms.TextBox();
            this.txtCustomerId = new System.Windows.Forms.TextBox();
            this.groupBox1Menu.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox1Menu
            // 
            this.groupBox1Menu.Controls.Add(this.txtEggCount);
            this.groupBox1Menu.Controls.Add(this.txtChickenCount);
            this.groupBox1Menu.Controls.Add(this.cmbDrinks);
            this.groupBox1Menu.Controls.Add(this.label1);
            this.groupBox1Menu.Controls.Add(this.label1HowManyEgg);
            this.groupBox1Menu.Controls.Add(this.label1HowManyChicken);
            this.groupBox1Menu.Location = new System.Drawing.Point(42, 12);
            this.groupBox1Menu.Name = "groupBox1Menu";
            this.groupBox1Menu.Size = new System.Drawing.Size(366, 96);
            this.groupBox1Menu.TabIndex = 6;
            this.groupBox1Menu.TabStop = false;
            this.groupBox1Menu.Text = "Menu";
            // 
            // txtEggCount
            // 
            this.txtEggCount.Location = new System.Drawing.Point(124, 46);
            this.txtEggCount.Name = "txtEggCount";
            this.txtEggCount.Size = new System.Drawing.Size(33, 20);
            this.txtEggCount.TabIndex = 12;
            // 
            // txtChickenCount
            // 
            this.txtChickenCount.Location = new System.Drawing.Point(124, 18);
            this.txtChickenCount.Name = "txtChickenCount";
            this.txtChickenCount.Size = new System.Drawing.Size(33, 20);
            this.txtChickenCount.TabIndex = 11;
            // 
            // cmbDrinks
            // 
            this.cmbDrinks.FormattingEnabled = true;
            this.cmbDrinks.Items.AddRange(new object[] {
            "Tea",
            "Pepsi",
            "Coca-cola",
            "NoDrink"});
            this.cmbDrinks.Location = new System.Drawing.Point(224, 19);
            this.cmbDrinks.Name = "cmbDrinks";
            this.cmbDrinks.Size = new System.Drawing.Size(121, 21);
            this.cmbDrinks.TabIndex = 10;
            this.cmbDrinks.Text = "Drinks";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(14, 46);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(84, 13);
            this.label1.TabIndex = 9;
            this.label1.Text = "How many egg?";
            // 
            // label1HowManyEgg
            // 
            this.label1HowManyEgg.AutoSize = true;
            this.label1HowManyEgg.Location = new System.Drawing.Point(8, 46);
            this.label1HowManyEgg.Name = "label1HowManyEgg";
            this.label1HowManyEgg.Size = new System.Drawing.Size(0, 13);
            this.label1HowManyEgg.TabIndex = 4;
            // 
            // label1HowManyChicken
            // 
            this.label1HowManyChicken.AutoSize = true;
            this.label1HowManyChicken.Location = new System.Drawing.Point(8, 18);
            this.label1HowManyChicken.Name = "label1HowManyChicken";
            this.label1HowManyChicken.Size = new System.Drawing.Size(107, 13);
            this.label1HowManyChicken.TabIndex = 3;
            this.label1HowManyChicken.Text = "How many chicken ?";
            // 
            // btnRecieveRequest
            // 
            this.btnRecieveRequest.Location = new System.Drawing.Point(115, 114);
            this.btnRecieveRequest.Name = "btnRecieveRequest";
            this.btnRecieveRequest.Size = new System.Drawing.Size(206, 23);
            this.btnRecieveRequest.TabIndex = 7;
            this.btnRecieveRequest.Text = "Recieve this request from a customer";
            this.btnRecieveRequest.UseVisualStyleBackColor = true;
            this.btnRecieveRequest.Click += new System.EventHandler(this.btnRecieveRequest_Click);
            // 
            // btnSendAllCustomerRequest
            // 
            this.btnSendAllCustomerRequest.Location = new System.Drawing.Point(115, 152);
            this.btnSendAllCustomerRequest.Name = "btnSendAllCustomerRequest";
            this.btnSendAllCustomerRequest.Size = new System.Drawing.Size(206, 23);
            this.btnSendAllCustomerRequest.TabIndex = 8;
            this.btnSendAllCustomerRequest.Text = "Send All Customer request to the Cook";
            this.btnSendAllCustomerRequest.UseVisualStyleBackColor = true;
            this.btnSendAllCustomerRequest.Click += new System.EventHandler(this.btnSendAllCustomerRequest_Click);
            // 
            // btnServePreparedFood
            // 
            this.btnServePreparedFood.Location = new System.Drawing.Point(115, 200);
            this.btnServePreparedFood.Name = "btnServePreparedFood";
            this.btnServePreparedFood.Size = new System.Drawing.Size(206, 23);
            this.btnServePreparedFood.TabIndex = 9;
            this.btnServePreparedFood.Text = "Serve prepared food to the customer";
            this.btnServePreparedFood.UseVisualStyleBackColor = true;
            this.btnServePreparedFood.Click += new System.EventHandler(this.btnServePreparedFood_Click);
            // 
            // label1Results
            // 
            this.label1Results.AutoSize = true;
            this.label1Results.Location = new System.Drawing.Point(39, 229);
            this.label1Results.Name = "label1Results";
            this.label1Results.Size = new System.Drawing.Size(42, 13);
            this.label1Results.TabIndex = 11;
            this.label1Results.Text = "Results";
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(335, 396);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(75, 23);
            this.button1.TabIndex = 12;
            this.button1.Text = "Clear";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // txtResult
            // 
            this.txtResult.Location = new System.Drawing.Point(59, 258);
            this.txtResult.Multiline = true;
            this.txtResult.Name = "txtResult";
            this.txtResult.Size = new System.Drawing.Size(328, 132);
            this.txtResult.TabIndex = 14;
            // 
            // txtCustomerId
            // 
            this.txtCustomerId.Location = new System.Drawing.Point(338, 114);
            this.txtCustomerId.Name = "txtCustomerId";
            this.txtCustomerId.Size = new System.Drawing.Size(49, 20);
            this.txtCustomerId.TabIndex = 13;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(450, 450);
            this.Controls.Add(this.txtCustomerId);
            this.Controls.Add(this.txtResult);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.label1Results);
            this.Controls.Add(this.btnServePreparedFood);
            this.Controls.Add(this.btnSendAllCustomerRequest);
            this.Controls.Add(this.btnRecieveRequest);
            this.Controls.Add(this.groupBox1Menu);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.groupBox1Menu.ResumeLayout(false);
            this.groupBox1Menu.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox1Menu;
        private System.Windows.Forms.ComboBox cmbDrinks;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label1HowManyEgg;
        private System.Windows.Forms.Label label1HowManyChicken;
        private System.Windows.Forms.Button btnRecieveRequest;
        private System.Windows.Forms.Button btnSendAllCustomerRequest;
        private System.Windows.Forms.Button btnServePreparedFood;
        private System.Windows.Forms.Label label1Results;
        private System.Windows.Forms.TextBox txtEggCount;
        private System.Windows.Forms.TextBox txtChickenCount;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.TextBox txtResult;
        private System.Windows.Forms.TextBox txtCustomerId;
    }
}

