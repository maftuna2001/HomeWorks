﻿using System;
using System.Windows.Forms;

namespace restaurant3
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        Cook cook = new Cook();
        Server server = new Server();
        TableRequest request = new TableRequest();

        private void btnRecieveRequest_Click(object sender, EventArgs e)
        {
            int chickenQuantity = Convert.ToInt32(txtChickenCount.Text);
            int eggQuantity = Convert.ToInt32(txtEggCount.Text);
            string drink = cmbDrinks.SelectedItem.ToString();
            int customerId = Convert.ToInt32(txtCustomerId.Text);
            request = server.Recieve(customerId, chickenQuantity, eggQuantity, drink);
        }

        private void btnServePreparedFood_Click(object sender, EventArgs e)
        {
            txtResult.Text = server.Serve();
        }

        private void btnSendAllCustomerRequest_Click(object sender, EventArgs e)
        {
            server.Send(request);
        }

        private void button1_Click(object sender, EventArgs e)
        {
            cmbDrinks.SelectedIndex = 0;
            txtChickenCount.Text = string.Empty;
            txtEggCount.Text = string.Empty;
            txtResult.Text = string.Empty;


        }

        private void Form1_Load(object sender, EventArgs e)
        {
            cmbDrinks.DataSource = Enum.GetValues(typeof(Drinks));
        }
    }
}
