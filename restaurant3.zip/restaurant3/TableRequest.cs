﻿using System;
using System.Collections.Generic;

namespace restaurant3
{

    public class TableRequest
    {

        public string requestStatus = "none";
        List<IMenuItem> singleCustomerOrder = new List<IMenuItem>();
        Dictionary<int, List<IMenuItem>> tableRequest = new Dictionary<int, List<IMenuItem>>();

        public void Add(int customerId, IMenuItem menuItem)//исправить добавляет только первый вариант напитка 
        {
            int counter;
            singleCustomerOrder.Add(menuItem);
            tableRequest[customerId] = singleCustomerOrder;
            requestStatus = "ordered ";
        }


        private bool isCustomerExist(int customerId)
        {
            if (tableRequest[customerId] == null)
            {
                return false;
            }
            else
                return true;
        }


        public IMenuItem[] this[int customerId]
        {
            get
            {
                return tableRequest[customerId].ToArray();
            }
        }


        public IMenuItem[] this[IMenuItem item]
        {
            get
            {
                IMenuItem[] menuItemArray = new IMenuItem[0];
                foreach (var request in tableRequest)
                {
                    foreach (var order in request.Value)
                    {
                        if (order.GetType() == item.GetType())
                        {
                            Array.Resize(ref menuItemArray, menuItemArray.Length + 1);
                            menuItemArray[menuItemArray.Length - 1] = order;
                        }
                    }
                }
                return menuItemArray;
            }
        }


        public int[] GetCustomerIds()
        {
            var customerIds = new int[tableRequest.Count];
            int i = 0;
            foreach (var request in tableRequest)
            {
                customerIds[i] = request.Key;
                i++;
            }
            return customerIds;
        }
    }
}



