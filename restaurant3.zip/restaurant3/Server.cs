﻿using System;

namespace restaurant3
{

    public class Server
    {
        TableRequest tableRequest = new TableRequest();
        IMenuItem[] singleRequest = null;
        public int customerCounter = 1;
        public int ChickenQuantity { get; set; }
        public int EggQuantity { get; set; }
        public TableRequest Recieve(int customer, int chickenQuantity, int eggQuantity, string drinkType)
        {
            //  MenuItem[] singleOrder = new MenuItem[chickenQuantity + eggQuantity + 1];

            for (int i = 0; i < chickenQuantity; i++)
            {
                tableRequest.Add(customer, new Chicken());
            }
            for (int j = 0; j < eggQuantity; j++)
            {
                tableRequest.Add(customer, new Egg());
            }
            switch (drinkType)
            {
                case "Tea ":
                    tableRequest.Add(customer, new Tea());
                    break;
                case " CocaCola":
                    tableRequest.Add(customer, new CocaCola());
                    break;
                case "Pepsi":
                    tableRequest.Add(customer, new Pepsi());
                    break;
                default:
                    tableRequest.Add(customer, new NoDrink());
                    break;
            }
            customerCounter++;

            tableRequest.requestStatus = "ordered";
            if (chickenQuantity == 0 && eggQuantity == 0 && drinkType == "NoDrink")
                throw new Exception("You didnt ordered anything , please choose menu items ");
            if (customerCounter > 8)
                throw new Exception("Request from one table should be 8");
            Console.WriteLine($"Recieve called with customer {customer}, chickenQuantity {chickenQuantity}, eggQuantity {eggQuantity}, drinkType {drinkType}");
            return tableRequest;
        }

        public void Send(TableRequest request)
        {
            Cook cook = new Cook();
            cook.Proccess(request);
        }

        public string Serve()
        {
            string result = "";

            if (tableRequest.requestStatus == "cooked ")
            {
                int[] customerIds = tableRequest.GetCustomerIds();


                foreach (var customerId in customerIds)
                {
                    int ChickenQuantity = 0;  // Объявление и инициализация внутри цикла
                    int EggQuantity = 0;
                    singleRequest = tableRequest[customerId];

                    foreach (IMenuItem item in singleRequest)
                    {
                        if (item is Chicken)
                        {
                            ChickenQuantity++;
                        }
                        else if (item is Egg)
                        {
                            EggQuantity++;
                        }
                        else
                        {
                            item.Obtain();
                        }
                        item.Serve();
                    }

                    result += $"Customer :{customerId}   is ordered: " +
                        $"{ChickenQuantity}  chickens , " +
                        $"{EggQuantity}  eggs . Enjoy your meal!";
                }
                tableRequest.requestStatus = "served";
            }
            else
            {
                result = "No order to serve ";
            }
            return result;
        }

    }
}

