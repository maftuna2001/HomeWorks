﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace restaurant3
{
       public   sealed class CocaCola : Drink
        {
        public new void Obtain()
        {
            Console.WriteLine("");
        }
        public new void Serve()
        {
            Console.WriteLine("");
        }
    }
    
}
