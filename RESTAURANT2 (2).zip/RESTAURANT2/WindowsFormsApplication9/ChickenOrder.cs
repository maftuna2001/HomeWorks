﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WindowsFormsApplication9
{
    class ChickenOrder:Order
    {
       
       public ChickenOrder (int quantity):base (quantity)
        {

        }

        public void CutUp()
        {
            Console.WriteLine();
        }
        public override void Cook()
        {
            Console.WriteLine("Chicken cooked");

        }
     
    }
}
