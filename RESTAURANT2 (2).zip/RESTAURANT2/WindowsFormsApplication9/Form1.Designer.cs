﻿namespace WindowsFormsApplication9
{
    partial class Form1
    {
        /// <summary>
        /// Обязательная переменная конструктора.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Освободить все используемые ресурсы.
        /// </summary>
        /// <param name="disposing">истинно, если управляемый ресурс должен быть удален; иначе ложно.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Код, автоматически созданный конструктором форм Windows

        /// <summary>
        /// Требуемый метод для поддержки конструктора — не изменяйте 
        /// содержимое этого метода с помощью редактора кода.
        /// </summary>
        private void InitializeComponent()
        {
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            this.listBox1 = new System.Windows.Forms.ListBox();
            this.lblResult = new System.Windows.Forms.Label();
            this.lblEggQl = new System.Windows.Forms.Label();
            this.btnServeFood = new System.Windows.Forms.Button();
            this.btnSendAllToCook = new System.Windows.Forms.Button();
            this.btnRecieve = new System.Windows.Forms.Button();
            this.txtEggCount = new System.Windows.Forms.TextBox();
            this.txtChickenCount = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.comboBox1);
            this.groupBox1.Controls.Add(this.listBox1);
            this.groupBox1.Controls.Add(this.lblResult);
            this.groupBox1.Controls.Add(this.lblEggQl);
            this.groupBox1.Controls.Add(this.btnServeFood);
            this.groupBox1.Controls.Add(this.btnSendAllToCook);
            this.groupBox1.Controls.Add(this.btnRecieve);
            this.groupBox1.Controls.Add(this.txtEggCount);
            this.groupBox1.Controls.Add(this.txtChickenCount);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Location = new System.Drawing.Point(47, 31);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(513, 371);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Menu ";
            this.groupBox1.Enter += new System.EventHandler(this.groupBox1_Enter);
            // 
            // comboBox1
            // 
            this.comboBox1.FormattingEnabled = true;
            this.comboBox1.Items.AddRange(new object[] {
            "Tea ",
            "Juice",
            "RC",
            "Coffee",
            "Mohito",
            "No Drink"});
            this.comboBox1.Location = new System.Drawing.Point(316, 19);
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Size = new System.Drawing.Size(151, 21);
            this.comboBox1.TabIndex = 10;
            this.comboBox1.SelectedIndexChanged += new System.EventHandler(this.comboBox1_SelectedIndexChanged);
            // 
            // listBox1
            // 
            this.listBox1.FormattingEnabled = true;
            this.listBox1.Location = new System.Drawing.Point(108, 248);
            this.listBox1.Name = "listBox1";
            this.listBox1.Size = new System.Drawing.Size(288, 95);
            this.listBox1.TabIndex = 9;
            this.listBox1.SelectedIndexChanged += new System.EventHandler(this.listBox1_SelectedIndexChanged);
            // 
            // lblResult
            // 
            this.lblResult.AutoSize = true;
            this.lblResult.Location = new System.Drawing.Point(36, 251);
            this.lblResult.Name = "lblResult";
            this.lblResult.Size = new System.Drawing.Size(35, 13);
            this.lblResult.TabIndex = 8;
            this.lblResult.Text = "result ";
            // 
            // lblEggQl
            // 
            this.lblEggQl.AutoSize = true;
            this.lblEggQl.Location = new System.Drawing.Point(33, 213);
            this.lblEggQl.Name = "lblEggQl";
            this.lblEggQl.Size = new System.Drawing.Size(64, 13);
            this.lblEggQl.TabIndex = 7;
            this.lblEggQl.Text = "Egg Quality:";
            // 
            // btnServeFood
            // 
            this.btnServeFood.Location = new System.Drawing.Point(143, 190);
            this.btnServeFood.Name = "btnServeFood";
            this.btnServeFood.Size = new System.Drawing.Size(188, 23);
            this.btnServeFood.TabIndex = 6;
            this.btnServeFood.Text = "Serve prepared food to the customer";
            this.btnServeFood.UseVisualStyleBackColor = true;
            this.btnServeFood.Click += new System.EventHandler(this.btnServeFood_Click);
            // 
            // btnSendAllToCook
            // 
            this.btnSendAllToCook.Location = new System.Drawing.Point(122, 148);
            this.btnSendAllToCook.Name = "btnSendAllToCook";
            this.btnSendAllToCook.Size = new System.Drawing.Size(209, 23);
            this.btnSendAllToCook.TabIndex = 5;
            this.btnSendAllToCook.Text = "send all customer request to the cook";
            this.btnSendAllToCook.UseVisualStyleBackColor = true;
            this.btnSendAllToCook.Click += new System.EventHandler(this.btnSendAllToCook_Click);
            // 
            // btnRecieve
            // 
            this.btnRecieve.Location = new System.Drawing.Point(122, 103);
            this.btnRecieve.Name = "btnRecieve";
            this.btnRecieve.Size = new System.Drawing.Size(209, 23);
            this.btnRecieve.TabIndex = 4;
            this.btnRecieve.Text = "recieve this request from customer";
            this.btnRecieve.UseVisualStyleBackColor = true;
            this.btnRecieve.Click += new System.EventHandler(this.btnRecieve_Click);
            // 
            // txtEggCount
            // 
            this.txtEggCount.Location = new System.Drawing.Point(188, 41);
            this.txtEggCount.Name = "txtEggCount";
            this.txtEggCount.Size = new System.Drawing.Size(21, 20);
            this.txtEggCount.TabIndex = 3;
            // 
            // txtChickenCount
            // 
            this.txtChickenCount.Location = new System.Drawing.Point(188, 11);
            this.txtChickenCount.Name = "txtChickenCount";
            this.txtChickenCount.Size = new System.Drawing.Size(21, 20);
            this.txtChickenCount.TabIndex = 2;
            this.txtChickenCount.TextChanged += new System.EventHandler(this.txtChickenCount_TextChanged);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(58, 41);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(89, 13);
            this.label2.TabIndex = 1;
            this.label2.Text = "How many eggs?";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(58, 11);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(112, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "How many chickens ?";
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(480, 361);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(57, 23);
            this.button1.TabIndex = 10;
            this.button1.Text = "button1";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(572, 408);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.groupBox1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Label lblResult;
        private System.Windows.Forms.Label lblEggQl;
        private System.Windows.Forms.Button btnServeFood;
        private System.Windows.Forms.Button btnSendAllToCook;
        private System.Windows.Forms.Button btnRecieve;
        private System.Windows.Forms.TextBox txtEggCount;
        private System.Windows.Forms.TextBox txtChickenCount;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ComboBox comboBox1;
        public System.Windows.Forms.ListBox listBox1;
    }
}

