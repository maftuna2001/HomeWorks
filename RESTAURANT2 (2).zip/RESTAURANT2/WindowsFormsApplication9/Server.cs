﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WindowsFormsApplication9
{
   public  class Server
   {
        MenuItem[][] customers = new MenuItem[8][];
       
        public int[] customerNumbers = new int[8];
        public int count = 0;
        Cook cooker;
        public int RecieveRequest(int chickenQuantity, int eggQuantity, MenuItem drinkChoice)
        {
            if(count > 7)
            {
                throw new Exception("Server can receive only 8 customers requests.");
            }
            int customerNumber = count + 1;
            MenuItem[] singleOrder = new MenuItem[chickenQuantity + eggQuantity + 1];
            for (int i = 0; i < chickenQuantity; i++)
            {
                singleOrder[i] = MenuItem.Chicken;
            }
            for (int j = 0; j < eggQuantity; j++)
            {
                singleOrder[j + chickenQuantity] = MenuItem.Egg;

            }
            singleOrder[singleOrder.Length - 1] = (MenuItem)drinkChoice;

            customers[count] = singleOrder;
            customerNumbers[count] = customerNumber;
            count++;

            return customerNumber;
        }

        
        public void  SendRequest()
        {
            
           foreach(var customerRequest in customers)
            {
                cooker.SubmitRequest();
            }
        }
        public string Serve()
        {
            string servedItems = "";

            for (int i = 0; i < count; i++)
            {
                int customerNumber = customerNumbers[i];
                int chickenQuantity = 0;
                int eggQuantity = 0;
                MenuItem[] customerRequest = customers[i];

                foreach (var item in customerRequest)
                {
                    if (item == MenuItem.Chicken)
                    {
                        chickenQuantity++;
                    }
                    else if (item == MenuItem.Egg)
                    {
                        eggQuantity++;
                    }
                }

                string customerInfo = $"Customer:{customerNumber}, Chicken:{chickenQuantity}, Egg:{eggQuantity}";
                servedItems += customerInfo + Environment.NewLine;
            }

            servedItems += "Enjoy your meal"; // Add "Enjoy your meal" at the end

            return servedItems;
        
            }
        }

       
    }

