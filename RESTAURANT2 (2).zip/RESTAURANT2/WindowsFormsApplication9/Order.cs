﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WindowsFormsApplication9
{
    public class Order
    {
        private int quantity;

        public Order(int quantity)
        {
            this.quantity = quantity;
        }

        public int SubtractQuantity()
        {
            return quantity--;
        }

        public virtual void Cook()
        {
            Console.WriteLine("Cook");
        }

        public int GetQuantity()
        {
            return quantity;
        }
    }
}
