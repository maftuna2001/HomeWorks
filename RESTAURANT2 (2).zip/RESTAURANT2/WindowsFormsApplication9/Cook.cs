﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WindowsFormsApplication9
{
    public class Cook
    {

        public void SubmitRequest()
        {
            Console.WriteLine();
        }
        public string PrepareFood(object request)
        {

            if (request is ChickenOrder)
            {
                var chicken = request as ChickenOrder;
                new ChickenOrder(chicken.GetQuantity());
                for (int i = 0; i < chicken.GetQuantity(); i++)
                {
                    chicken.CutUp();
                }
                return "Chicken is prepared!";
            }
            else if (request is EggOrder)
            {
                var egg = request as EggOrder;

                for (int i = 0; i < egg.GetQuantity(); i++)
                {
                    try
                    {
                        egg.Crack();
                    }
                    catch (Exception ex)
                    {
                        throw new InvalidOperationException(ex.Message);
                    }
                    finally
                    {
                        egg.Discard();
                    }
                }
                egg.Cook();
                return $"{egg.GetQuantity()} Egg Has been Prepared.";

            }
            else
            {
                return "Something is wrong";
            }
            }



        }

    

        }
    

