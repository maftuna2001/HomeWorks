﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApplication9
{
    public partial class Form1 : Form
    {
        Cook cook = new Cook();
        Server server = new Server();
        public Form1()
        {
            InitializeComponent();
        }

        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)//form load 
        {

            comboBox1.DataSource = Enum.GetValues(typeof(MenuItem));
        }

        private void btnRecieve_Click(object sender, EventArgs e)
        {
 
            int chickenQuantity = Convert.ToInt32(txtChickenCount.Text);
            int eggQuantity = Convert.ToInt32(txtEggCount.Text);
            MenuItem drink;
            switch (comboBox1.SelectedItem.ToString())
            {
                case "Tea":
                    drink = MenuItem.Tea;
                    break;
                case "Coffee":
                    drink = MenuItem.Coffee;
                    break;
                case "Mohito":
                    drink = MenuItem.Mohito;
                    break;
                case "RC":
                    drink = MenuItem.Rc;
                    break;
                case "Juice":
                    drink = MenuItem.Juice;
                    break;
                default:
                    drink = MenuItem.Nodrinks;
                    break;
            }

            try
            {
                int assignedCustomerNumber = server.RecieveRequest(chickenQuantity, eggQuantity, drink );
                MessageBox.Show($"Order submitted successfully! Customer number: {assignedCustomerNumber}");
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message); // Show any exceptions that might occur
            }



        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void txtChickenCount_TextChanged(object sender, EventArgs e)
        {

        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            txtChickenCount.Text = "";
            txtEggCount.Text = "";
            comboBox1.SelectedIndex = -1; 

        
            listBox1.Items.Clear();

   
            server = new Server(); 
                                   
            cook = new Cook(); 

         
            server.count = 0;
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void btnSendAllToCook_Click(object sender, EventArgs e)
        {
            string chickenQuantityText = txtChickenCount.Text;
            int chickenQuantity;

            if (!int.TryParse(chickenQuantityText, out chickenQuantity))
            {
                Console.WriteLine(chickenQuantity);

            }

            else
            {
                ChickenOrder chickenOrder = new ChickenOrder(chickenQuantity);
                string result = cook.PrepareFood(chickenOrder);
                MessageBox.Show(result);
            }
            string eggQuantityText = txtEggCount.Text;
            int eggQuantity;
            if (!int.TryParse(eggQuantityText, out eggQuantity))
            {
                Console.WriteLine(eggQuantity);
            }
            else
            {
                EggOrder eggOrder = new EggOrder(eggQuantity);
                string result = cook.PrepareFood(eggOrder);
                MessageBox.Show(result);
            }

        }

        private void btnServeFood_Click(object sender, EventArgs e)
        {


            if (server == null || server.count == 0)
            {
                MessageBox.Show("No customer order to serve ");
                return;
            }

            string servedItems = server.Serve();

            // Split the served items by newline to add each item separately to the ListBox
            string[] servedItemsArray = servedItems.Split(new[] { "\r\n", "\r", "\n" }, StringSplitOptions.None);
            foreach (string item in servedItemsArray)
            {
                listBox1.Items.Add(item);
            }

            // Add "Enjoy your meal" at the end

        }
    }

    }