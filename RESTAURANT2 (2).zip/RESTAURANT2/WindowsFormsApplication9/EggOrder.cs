﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WindowsFormsApplication9
{
    public  class EggOrder:Order
    {
        public int quality;
        public EggOrder(int quantity):base (quantity )
       
        {
           
           quality= new Random().Next(101);

        }
        public int GetQuality()
        {
            return quality;
           
        }
        public void Crack()
        {
            Console.WriteLine();
        }
        public override void Cook()
        {
            Console.WriteLine ("Egg  cooked");

        }
        public void Discard()
        {

        }
      

    }
}
